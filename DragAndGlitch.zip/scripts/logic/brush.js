
function Brush (radius)
{
	this.radius = radius;
}